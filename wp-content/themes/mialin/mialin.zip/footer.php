	<footer>
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
					<div class="foot-o-nas">
						<div class="heading"> 
					    	<h4 class="title">О нас</h4>
						</div>
						<div class="box"> Мы видим, как с каждым годом возрастает спрос на потребительскую электронику и промышленную цифровую технику, что открывает для нашей компании поистине безграничные возможности для развития.</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
					<div class="foot-contact">
						<div class="heading"> 
					    	<h4 class="title">Контакты</h4>
						</div>
						<div class="box">
							<address><b><a href="http://www.smartbuy-russia.ru">http://www.mialin-auto.ru</a></b>
								<dl class="dl-horizontal">
									<dt><i class="fa fa-phone"></i></dt>
									<dd>8 (495) 662-32-52</dd>
									<dt><i class="fa fa-envelope"></i></dt>
									<dd><a href="mailto:mail@mialin-auto.ru">mail@mialin-auto.ru</a></dd>
									<dt><i class="fa fa-map-marker"></i></dt>
									<dd>г.Нальчик, ул. Идарова, 192а</dd>
								</dl>
							</address>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Здесь пишем код -->
	
	<div class="hidden"></div>

	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/libs/html5shiv/es5-shim.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/libs/html5shiv/html5shiv.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/libs/html5shiv/html5shiv-printshiv.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/libs/respond/respond.min.js"></script>
	<![endif]-->

	<script src="<?php echo get_template_directory_uri(); ?>/libs/jquery/jquery-1.11.2.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/libs/menu/menu.js" type="text/javascript"></script> 
	<script src="<?php echo get_template_directory_uri(); ?>/libs/waypoints/waypoints.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/libs/animate/animate-css.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/libs/plugins-scroll/plugins-scroll.js"></script>
	
    <script src="<?php echo get_template_directory_uri(); ?>/libs/owl/owl.carousel.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/libs/bx/jquery.bxslider.min.js"></script>
	
	<script src="<?php echo get_template_directory_uri(); ?>/js/common.js"></script>
	<?php wp_footer(); ?>
</body>
</html>